/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   fsmore.h
 * Author: student
 *
 * Created on September 18, 2023, 11:44 PM
 */

#ifndef FSMORE_H
#define FSMORE_H

#ifdef __cplusplus
extern "C" {
#endif

    void cmore();


#ifdef __cplusplus
}
#endif

#endif /* FSMORE_H */

